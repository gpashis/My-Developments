/*
 * GreenPrint Getting Started scripts.
*/

var theAPP = window.JavaScriptHandler,
	appHandler = (typeof theAPP !== 'undefined'),
	isTutorialLoaded = true,
	isDraging = false,
	x = 0,
	y = 0,
	theWidth,
	currentScreen = 0,
	isScreenLoaded = false,
	
	gettingStarted = {
	
	// Check total number of sections for the entire app
	totalSections: function(section) {
		var sectionLength = $("#content_wrapper .content_section").length;
		if (section >= sectionLength) {
			return 0;
		}
		return section;
	},
	
	//Set left value for each sections to arrange them side by side for a scrolling effect
	sizeContent: function() {
		theWidth = $("#content_wrapper .content_section").width();
		var contentCount = 0;
		$("#content_wrapper .content_section").each(function (i) {
			contentCount += i;
			$(this).css('left', i * theWidth);
		});
	},
	
	//Scroll the content to show the required section
	scrollContent: function(screenNo) {
		currentScreen = gettingStarted.totalSections(screenNo);
		if(!isScreenLoaded)
		{
			isScreenLoaded = true;
			$("#content_wrapper").animate({ scrollLeft: screenNo * theWidth }, 1000, function(){
				isScreenLoaded = false;				
				if(1==screenNo){					
					$(".foot_left").animate({scrollLeft: 700}, 700, function(){
						//Play the tutorial slide
						$('#iview').trigger('iView:play');
					});
				}
				else if (0==screenNo)
				{
					//Reset Toturial Slide to begin
					$('#iview').trigger('iView:goSlide', [0]);					
					//pause the tutorial Slider
					$('#iview').trigger('iView:pause');					
					$(".foot_left").animate({scrollLeft: 0}, 300);
				}
			});
		}
	},
	
	//Scroll to next section
	scrollContentNext: function() {
    	gettingStarted.scrollContent(currentScreen + 1);
	},
	
	//Scroll back to previous section
	scrollContentPrev: function() {
    	gettingStarted.scrollContent(currentScreen - 1);
	},
	
	//PNG fix for IE 6
    ieFix: function(){
		if ($.browser.msie && ($.browser.version == "6.0")) {
			$('#content_wrapper').supersleight();
		}
		// Internet Explorer black border Issue for fading effect
		/*else if ($.browser.msie && ($.browser.version == "8.0" || $.browser.version == "7.0")) {
			var els = $("#iview").find('img');
			for (i=0; i<els.length; i++) {
				var s = els[i].src;
				els[i].style.filter += "progid:DXImageTransform.Microsoft.AlphaImageLoader(src='" + s + "', sizingMethod=image);";
			}
		}*/
	},
	
	// Modal welcome screen
	modalWindow: function(showWelcomeDlg){
		$('#welcome_dialog').jqm({
			trigger: '#ex3aTrigger',
			overlay: 30,
			overlayClass: 'whiteOverlay'
		});	
		
		if (showWelcomeDlg) {
			$('#welcome_dialog').jqmShow();
		}
	
		// Close Button Highlighting. (browser compatible codes as IE doesn't support :hover)
		$('input.jqmdX')
			.hover(function () {
				$(this).addClass('jqmdXFocus');
			}, function () {
				$(this).removeClass('jqmdXFocus');
			}).focus(function () {
				this.hideFocus = true; $(this).addClass('jqmdXFocus');
			}).blur(function () {
				$(this).removeClass('jqmdXFocus');
		});
	
	},
	
	//Bind Events Handlers
	attachAllEvents: function(){
		
		//Close Window
		$(".close_app").click(function () {
			if (appHandler) {
				theAPP.CloseDialog();
			}
		});
				
		//Launch Settings App
		$('#advanced_settings').click(function () {
			if (appHandler) {
				theAPP.LaunchAdvancedSetting();
			}
		});
	
		//On printer Selection change Send the selected printer ID.
		$('#target_printer').change(function () {
			var dropdownvalue = $('#target_printer option:selected').val();
			if (appHandler) {
				theAPP.SetDefaultPrinter(dropdownvalue);
			}
		});
	
		//On checkbox selection change
		$('#report_anonymous_stats').change(function () {
			//var checkVal = $('#target_printer option:selected').val();
			var bcheckedVal = false;
			var checkedVal = $('#report_anonymous_stats').attr('checked');
			if (checkedVal == "checked") {
				bcheckedVal = true;
			}
	
			if (appHandler) {
				theAPP.AnonymousReportStats(bcheckedVal);
			}
		});
	
		//Stop Dragging on mouse enter on the document
		$('#content_wrapper').bind('mouseup mouseleave', function (e) {
			isDraging = false;
			x = 0;
			y = 0;
		});
	
		//Stop Dragging on these elements
		$('select, input[type=checkbox]').bind('mouseup mouseleave mousedown mousemove', function (e) {
			isDraging = false;
		});
	
		//Stop Image Dragging
		$(document).bind("dragstart", function(e) {
			 if ((e.target.nodeName.toUpperCase() == "IMG") || (e.target.nodeName.toUpperCase() == "A")) {
				 return false;
			 }
		});
		
		//Move Window
		$('#content_wrapper').mousedown(function (e) {
			isDraging = true;
			x = e.pageX;
			y = e.pageY;
		}).mousemove(function (e) {
			if (true == isDraging) {
				var x1 = e.pageX - x;
				var y1 = e.pageY - y;
				if (appHandler) {
					theAPP.MoveWindow(x1, y1);
				}
			}
		});
		
		//Move to second screen
		$(".watch_tutorials a").click(function(e) {
			//Init Tutorial Slides
			if(isTutorialLoaded)
			{		
				$('#iview').iView({
					fx:'random',
					pauseTime: 7000,
					pauseOnHover: true,
					controlNav: true,
					controlNavHoverOpacity: 0.4,
					directionNav: false,
					timer: "Bar",
					timerDiameter: 200,
					timerPadding: 0,
					timerStroke: 2,
					timerBarStroke: 0,
					timerX: 15,
        			timerY: 25,
					timerColor: "#FFF",
					timerPosition: "bottom-left",
					animationSpeed:300,
					onSlideShowEnd: function () {
						$('#iview').trigger('iView:goSlide', [6]);
						$('#iview').trigger('iView:pause');
					}
				});
			}
			
			isTutorialLoaded = false;
			$('#tutorial_buttons a').css({'opacity':1});
			
			//start animation
			gettingStarted.scrollContent(1);
						
			e.preventDefault();
		});
		
		$('#tutorial_buttons a').click(function(e){
			$('#tutorial_buttons a').css({'opacity':0});
			//start animation
			gettingStarted.scrollContent(0);
			
			e.preventDefault();
		});
		
	},
	//Initialize Application
	init: function() {
		gettingStarted.sizeContent();
		gettingStarted.ieFix();
		gettingStarted.attachAllEvents();
	}
}

//This function is called be Host to set the default printer.
function setDefaultPrinter(uniqueID)
{
	$("#target_printer").val(uniqueID);
}

//on Anonymous Report Stats Changed 
function onAnonymousReportStatsChanged()
{
	if (appHandler)
	{
		theAPP.AnonymousReportStats($('#report_anonymous_stats').attr('checked'));
	}
}

//This Function is called by Host to set the list of printers.
function setPrinterList(vPrinterList)
{
	var varient = new VBArray(vPrinterList);
	var printerList = varient.toArray();
	var myselect = document.getElementById("target_printer");
	myselect.innerHTML = "";
	for (var i = 0; i < printerList.length; i++)
	{
		checkval = printerList[i].split(',');
		myselect.options[i]=new Option(checkval[0],checkval[1]);
		myselect.options[i].title = checkval[0]; //Add tooltip for long names
	}
}

//set Report Anonymous Stats
function setReportAnonymousStats(bCheck)
{	
	$('#report_anonymous_stats').prop('checked', bCheck);
}

//set LicenceInfo
function setLicenceInfo(licenceType, daysLeft, trialExpired)
{
	//eHomePremiumTrial = 0 (Home Premium Trial); eHomePremium = 1 (Home Premium);
	$('#try, #buy').show();
	$('#close').hide();
	
	//Showing the Buy now option
	if(1 == licenceType)
	{
		$('#try, #buy').hide();
		$('#close').show();
	}
	
	//Showing additional infomration
	if ((0 == licenceType) && (true == trialExpired)) {
		if (true == trialExpired)
		{
			//Trial expired.
		}
		else
		{
			//'You have' + daysLeft + 'days to use this product';
		}
	}
	else if ((1 != licenceType) && (0 != licenceType))
	{
		//product is not registered. license is invalid.
	}
}

//Adjust Fontsize based on Screen DPI
//72, 96, 125, 144, 150
function setFontSize(screenDPI)
{	
	if ((screenDPI > 100) && (screenDPI <= 125)) {
		// 100dpi to 125dpi
		$('body').addClass('dpi_125');
	} else if ((screenDPI > 125) && (screenDPI <= 150)) {
		// 125dpi to 150dpi
		$('body').addClass('dpi_150');
	} else {
		// set default
		$('body').addClass('dpi_100');
	}
}

// Document Ready
// --------------------------------------------
$(document).ready(function () {
	gettingStarted.init();
});