// JavaScript Document

var theWidth,
	currentScreen = 0,
	clicked = false,
	appHandler = (typeof window.ScannerHandler !== 'undefined'),
	GP_Scanner = {
	// Check total number of sections for the entire app
	totalSections: function(section) {
		var sectionLength = $("#content_wrapper section").length;
		if (section >= sectionLength) {
			return 0;
		}
		return section;
	},
	//Set left value for each sections to arrange them side by side for a scrolling effect
	sizeContent: function() {
		theWidth = $("#content_wrapper section").width();
		var contentCount = 0;
		$("#content_wrapper section").each(function (i) {
			contentCount += i;
			$(this).css('left', i * theWidth);
		});
	},
	//Scroll the content to show the required section
	scrollContent: function(screenNo) {
		currentScreen = GP_Scanner.totalSections(screenNo);
		GP_Scanner.gpLoader.show();
		if(!clicked)
		{
			clicked = true;
			$("#content_wrapper").animate({
					scrollLeft: screenNo * theWidth
				}, 1000, function(){
				clicked = false;
				GP_Scanner.gpLoader.hide();
			});
		}
		if (1 == screenNo){
			GP_Scanner.getAdopterInfo();
			//init IP Address plugin
        	$('.ip').ipaddress();
			//focus to the first IP range input
			//$('#ip_start_octet_1').focus();
		}
		else if(2==screenNo){
			GP_Scanner.discovery.start();
		}
		else if(3==screenNo){
			GP_Scanner.loadChart();
		}
		else if(4==screenNo)
		{
			GP_Scanner.viewResults();
		}
	},
	//Scroll to next section
	scrollContentNext: function() {
    	GP_Scanner.scrollContent(currentScreen + 1);
	},
	//Scroll back to previous section
	scrollContentPrev: function() {
    	GP_Scanner.scrollContent(currentScreen - 1);
	},
	gpLoader: {
		show: function() {
			$("#loader").fadeIn('slow');
		},
		hide: function() {
			$("#loader").fadeOut("slow");
		}
	},
	//Close the Application
	closeApp:function() {
		if(appHandler)
			window.ScannerHandler.CloseApplication();
	},
	discovery: {
		init: function(txStartIP, txEndIP, onDiscoveryProgress) {
			if(appHandler)
				window.ScannerHandler.QuickScanDevices(txStartIP, txEndIP, onDiscoveryProgress);
		},
		progress: function(progressState, progressLayer, progressPrinterCount) {
			if (1 == progressState)
			{
				$("#printer_count").html(progressPrinterCount);
				$("#results_printer_count").html(progressPrinterCount);
				//reset spinner color
				$("#loading_spinner div").removeClass('step1 step2 step3').addClass('step1');				
				//Show Progress Layers
				if(1==progressLayer){
					//Spinner Color [yellow]
					$("#loading_spinner div").removeClass('step1 step2 step3').addClass('step2');					
				} else if (3==progressLayer) {
					//Spinner Color [red]
					$("#loading_spinner div").removeClass('step1 step2 step3').addClass('step3');					
				}
			}
			else
			{
				//move to next screen
				GP_Scanner.scrollContent(3);
				
				//Update the scan History.
				//updateScanHistory();
				
				//Update Scanned Devices.
				//updateScannedDevices();
			}
		},
		start: function() {
			var txStartIP = $('#ip_start').val().toString();
			var txEndIP = $('#ip_end').val().toString();
			//initialize discovery
			GP_Scanner.discovery.init(txStartIP, txEndIP, GP_Scanner.discovery.progress);
		}
	},
	getAdopterInfo: function() {
		//Get the Adopter Info.
		if(appHandler)
		{
			var adopterInfo = window.ScannerHandler.GetAdopterInfo();
			
			for (i = 0; i < adopterInfo.length; i++){
				//Get the Adopter name.
				var adopterName = adopterInfo[i][0];			
				//Get the IP addres.
				var ipAdress = adopterInfo[i][1];			
				//Start Range.
				var startIP = adopterInfo[i][2];			
				//End Range.
				var endIP = adopterInfo[i][3];
				
				var optionData = {
					adopterName : adopterName
				};
			}
		}
		
		//set the IP values
		$("#my_ip").html(ipAdress);
		$("#ip_start").val(startIP);
		$("#ip_end").val(endIP);
		
		/*var data = {
			"192.168.10.1-192.168.10.100": "Network Adapter1",
			"192.168.10.101-192.168.10.200": "Network Adapter2"
		};*/
		
		//Clear all options from selectbox
		$("select#network_adapters").empty();
		
		//Set Adapters Option Values
		$.each(optionData, function (key, value) {
            $("select#network_adapters").append(
				$("<option>", {
					text: value,
					value: key
					//selected: true
				})
				//$("<option></option>").attr("value", key).text(value)
			);
        });

	},
	viewResults: function() {
		
		//Get the company list.
		if(appHandler)
			var scanedDevices = window.ScannerHandler.GetScannedDevices('');
		
		//alert(scanedDevices.length);
		var tableData = new Array();
		
		//Loop through all the element and update the company name.
		for (var i = 0; i < scanedDevices.length; i++)
		{
			tableData[i] = [
						scanedDevices[i][0],
						scanedDevices[i][3],
						scanedDevices[i][6],
						'--',
						scanedDevices[i][8],
						"0"
					];
		}
		
		// Table Column Names
		var tableColumns = [
							 { "sTitle": "IP" },
							 { "sTitle": "Device" },
							 { "sTitle": "Location" },
							 { "sTitle": "Color Device" },
							 { "sTitle": "Life Count" },
							 { "sTitle": "Color Count" }
						   ];

		//Initialize dataTables with data
		$('#scan_datatables').dataTable({
			"aaData": tableData,
			"aoColumns": tableColumns,
			"bLengthChange": true,
			"bAutoWidth": false,
			"sPaginationType": "full_numbers",
			"sScrollY": "220px",
			"sDom": '<"dataTable_top"lf>rt<"dataTable_bottom"pi>',
			"bDestroy": true
		});
	
	},
	//Overlays
	overlayBox: {
		init: function() {
			$("a[rel]").overlay({
				top: 100,
				// some mask tweaks suitable for facebox-looking dialogs
				mask: {
					color: '#000',
					loadSpeed: 200,
					opacity: 0.5
				},
				// disable this for modal dialog-type of overlays
				closeOnClick: false
				//effect: 'apple'
			});
		},
		//Close all Overlays
		closeAll: function() {
			$("a[rel]").each(function() {
				$(this).overlay().close();
			});
		},
		//Open all Overlays
		openAll: function() {
			$("a[rel]").each(function() {
				$(this).overlay().load();
			});
		}
	},
	//Charts
	loadChart: function() {
		var chartData = [];
		var series = Math.floor(Math.random()*5)+1;
		chartData[0] = { label: "Color Printers", data:42, color: "#cb4b4b" };
		chartData[1] = { label: "B&W Printers", data:27, color: "#4da74d" };
		chartData[2] = { label: "Manufacturers", data:9, color: "#edc240" };
		
		// Scan Results Pie Chart
		$.plot($("#scan_results_pie_chart"), chartData,
		{
			series: {
				pie: { 
					show: true,
					radius:300,
					label: {
						show: true,
						formatter: function(label, series){
							return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'+label+'<br/>'+Math.round(series.percent)+'%</div>';
						},
						threshold: 0.1
					}
				}
			},
			legend: {
				show: false
			}
		});
	},
	localStore:{
		set: function(key, value) {
			//localStorage.name = 'Remy';
			window.localStorage.setItem(value, key);
		},
		destroy: function(name) {
			delete localStorage.name;
		}
	},
	errorLog:{
		init: function(errorTxt) {
			window.requestFileSystem  = window.requestFileSystem || window.webkitRequestFileSystem;
			/*window.requestFileSystem(
					window.TEMPORARY,5*1024*1024,
					GP_Scanner.errorLog.writeToFile,
					GP_Scanner.errorLog.logHandler
				);*/
			
			window.webkitStorageInfo.requestQuota(PERSISTENT, 5*1024*1024, function(grantedBytes) {
			  window.requestFileSystem(PERSISTENT, grantedBytes, GP_Scanner.errorLog.writeToFile, GP_Scanner.errorLog.logHandler);
			}, function(e) {
				console.log('Error', e);
			});
		},
		writeToFile: function(fs){
			fs.root.getFile('gpLog.txt', {create:true}, function(fileEntry){
				//fileEntry.isFile = true;
				//fileEntry.name = 'log.txt';
				fileEntry.fullPath = '/gpLog.txt';
				
				// Create a FileWriter object for our FileEntry (log.txt).
				fileEntry.createWriter(function(fileWriter){
					
					// Start write position at EOF.
					fileWriter.seek(fileWriter.length);
					
					//Write completed event
					fileWriter.onwriteend = function(e){
						console.log('Write completed.');
					};
					
					//Write error event
					fileWriter.onerror = function(e){
						console.log('Write failed: ' + e.toString());
					};
					
					// Create a new Blob and write it to log.txt.
					//var blob = new Blob(['some text'], {type:'text/plain'});
					var blob = new Blob(['line added by ashis'], {type:'text/plain'});
					fileWriter.write(blob);
					
				}, GP_Scanner.errorLog.logHandler);
				
			}, GP_Scanner.errorLog.logHandler);
		},		
		logHandler: function(e) {
			var msg = '';
			switch (e.code) {
				case FileError.QUOTA_EXCEEDED_ERR:
					msg = 'QUOTA_EXCEEDED_ERR';
				break;
				case FileError.NOT_FOUND_ERR:
					msg = 'NOT_FOUND_ERR';
				break;
				case FileError.SECURITY_ERR:
					msg = 'SECURITY_ERR';
				break;
				case FileError.INVALID_MODIFICATION_ERR:
					msg = 'INVALID_MODIFICATION_ERR';
				break;
				case FileError.INVALID_STATE_ERR:
					msg = 'INVALID_STATE_ERR';
				break;
				default:
					msg = 'Unknown Error';
				break;
			};
			console.log('Error: ' + msg);
		}
	},
	//Stack of functions to start application
	initApp: function() {
		
		GP_Scanner.errorLog.init('App initalized');
		
		// Load Content Sliders
		GP_Scanner.sizeContent();
		//Load Overlay Boxes
		GP_Scanner.overlayBox.init();
		//Load Charts
		//GP_Scanner.loadChart();
	}
}

// Document Ready
$(function() {	
	// Initialize Application on document ready
	GP_Scanner.initApp();
});